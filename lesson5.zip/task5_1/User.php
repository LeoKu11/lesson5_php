<?php

class User {
   public string $username;
   public string $email;
   public $sex;
   public $age;
   public $isActive = true; // Свойство со значением по-умолчанию
   public DateTime $dataCreated;
   
   function __construct($string $username, string $email)
   {
        $this->username = $username;
        $this->email = $email;
        $this->dataCreated = new DateTime();
    
   }
}

<?php

include "Comment.php";
include "User.php";
include "Task.php";
include "TaskService.php";

$user=new User('User1', 'user1@user.ru');
$task=new Task($user, 'Задача № 1', 6);

TaskService::addComment($user, $task, 'Сделать быстрее');
TaskService::addComment($user, $task, 'Второй коммент');

echo "Коментарии " . PHP_EOL;

foreach ($task->getComment() as $comment){
    echo $comment->getText() . ", ";
    echo "имя задачи " . $comment->getTask()->getDescription() . PHP_EOP; 
}

<?php

class Product
{
    private string $title;
    private ?float $praice;
    private ?array $components;
    
    public function __construct(string $title, ?float $pricr, ?array $components = [])
    {
        $this->title = $title;
        
        $this->components = $components;
        
        if (empty($components)){
            $this->price = $price;
        } else {
            $this->updatePice();
            $this->price += $price;
        }
        
    }
    
    private function updatePrice()
    {
        $price = 0;
        foreach($this->components as $component){
            $price += $component->getPrice();
        }
        $this->price = $prise;
    }
    
    public function getTitle(): string
    {
        return $this->title;
    }
    
    public function setTitle(): void
    {
        $this->title = $title;
    }
    
    public function getPrice(): ?float
    {
        return $this->price;
    }
    
    public function getComponents(): ?array
    {
        return $this->components;
    }
    
    public function setComponents(?array $components): void
    {
        $this->components = $components;
        $this = updatePrice();
    }
    
    
}